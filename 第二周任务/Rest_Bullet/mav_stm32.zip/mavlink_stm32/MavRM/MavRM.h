/** @file
 *  @brief MAVLink comm protocol generated from MavRM.xml
 *  @see http://mavlink.org
 */
#pragma once
#ifndef MAVLINK_MAVRM_H
#define MAVLINK_MAVRM_H

#ifndef MAVLINK_H
    #error Wrong include order: MAVLINK_MAVRM.H MUST NOT BE DIRECTLY USED. Include mavlink.h from the same directory instead or set ALL AND EVERY defines from MAVLINK.H manually accordingly, including the #define MAVLINK_H call.
#endif

#undef MAVLINK_THIS_XML_IDX
#define MAVLINK_THIS_XML_IDX 0

#ifdef __cplusplus
extern "C" {
#endif

// MESSAGE LENGTHS AND CRCS

#ifndef MAVLINK_MESSAGE_LENGTHS
#define MAVLINK_MESSAGE_LENGTHS {}
#endif

#ifndef MAVLINK_MESSAGE_CRCS
#define MAVLINK_MESSAGE_CRCS {{0, 50, 9, 0, 0, 0}, {1, 75, 9, 0, 0, 0}, {2, 220, 8, 0, 0, 0}}
#endif

#include "../protocol.h"

#define MAVLINK_ENABLED_MAVRM

// ENUM DEFINITIONS


/** @brief Micro air vehicle / autopilot classes. This identifies the individual model. */
#ifndef HAVE_ENUM_MAV_DEVICE
#define HAVE_ENUM_MAV_DEVICE
typedef enum MAV_DEVICE
{
   MAV_TX2=0, /* Nvidia Tegra X2 | */
   MAV_STM32=1, /* STM32 | */
   MAV_TK1=2, /* Nvidia Tegra K1 | */
   MAV_TX1=3, /* Nvidia Tegra X1 | */
   MAV_NUC=4, /* NUC with i7-8550U on x86-64 | */
   MAV_DEVICE_ENUM_END=5, /*  | */
} MAV_DEVICE;
#endif

/** @brief Micro air vehicle / autopilot classes. This identifies the individual model. */
#ifndef HAVE_ENUM_MAV_MSG_ID
#define HAVE_ENUM_MAV_MSG_ID
typedef enum MAV_MSG_ID
{
   MAV_MSG_HEARTBEAT=0, /* mavlink_heartbeat_packet | */
   MAV_MSG_GIMBAL_CONTROL=1, /* mavlink_gimbal_control | */
   MAV_MSG_CHASSIS_CONTROL=2, /* mavlink_chassis_control | */
   MAV_MSG_ID_ENUM_END=3, /*  | */
} MAV_MSG_ID;
#endif

/** @brief These flags encode the MAV mode. */
#ifndef HAVE_ENUM_MAV_MODE_FLAG
#define HAVE_ENUM_MAV_MODE_FLAG
typedef enum MAV_MODE_FLAG
{
   MAV_MODE_FLAG_CUSTOM_MODE_ENABLED=1, /* 0b00000001 Reserved for future use. | */
   MAV_MODE_FLAG_TEST_ENABLED=2, /* 0b00000010 system has a test mode enabled. This flag is intended for temporary system tests and should not be used for stable implementations. | */
   MAV_MODE_FLAG_AUTO_ENABLED=4, /* 0b00000100 autonomous mode enabled, system finds its own goal positions. Guided flag can be set or not, depends on the actual implementation. | */
   MAV_MODE_FLAG_GUIDED_ENABLED=8, /* 0b00001000 guided mode enabled, system flies waypoints / mission items. | */
   MAV_MODE_FLAG_STABILIZE_ENABLED=16, /* 0b00010000 system stabilizes electronically its attitude (and optionally position). It needs however further control inputs to move around. | */
   MAV_MODE_FLAG_HIL_ENABLED=32, /* 0b00100000 hardware in the loop simulation. All motors / actuators are blocked, but internal software is full operational. | */
   MAV_MODE_FLAG_MANUAL_INPUT_ENABLED=64, /* 0b01000000 remote control input is enabled. | */
   MAV_MODE_FLAG_SAFETY_ARMED=128, /* 0b10000000 MAV safety set to armed. Motors are enabled / running / can start. Ready to fly. Additional note: this flag is to be ignore when sent in the command MAV_CMD_DO_SET_MODE and MAV_CMD_COMPONENT_ARM_DISARM shall be used instead. The flag can still be used to report the armed state. | */
   MAV_MODE_FLAG_ENUM_END=129, /*  | */
} MAV_MODE_FLAG;
#endif

/** @brief These values encode the bit positions of the decode position. These values can be used to read the value of a flag bit by combining the base_mode variable with AND with the flag position value. The result will be either 0 or 1, depending on if the flag is set or not. */
#ifndef HAVE_ENUM_MAV_MODE_FLAG_DECODE_POSITION
#define HAVE_ENUM_MAV_MODE_FLAG_DECODE_POSITION
typedef enum MAV_MODE_FLAG_DECODE_POSITION
{
   MAV_MODE_FLAG_DECODE_POSITION_CUSTOM_MODE=1, /* Eighth bit: 00000001 | */
   MAV_MODE_FLAG_DECODE_POSITION_TEST=2, /* Seventh bit: 00000010 | */
   MAV_MODE_FLAG_DECODE_POSITION_AUTO=4, /* Sixt bit:   00000100 | */
   MAV_MODE_FLAG_DECODE_POSITION_GUIDED=8, /* Fifth bit:  00001000 | */
   MAV_MODE_FLAG_DECODE_POSITION_STABILIZE=16, /* Fourth bit: 00010000 | */
   MAV_MODE_FLAG_DECODE_POSITION_HIL=32, /* Third bit:  00100000 | */
   MAV_MODE_FLAG_DECODE_POSITION_MANUAL=64, /* Second bit: 01000000 | */
   MAV_MODE_FLAG_DECODE_POSITION_SAFETY=128, /* First bit:  10000000 | */
   MAV_MODE_FLAG_DECODE_POSITION_ENUM_END=129, /*  | */
} MAV_MODE_FLAG_DECODE_POSITION;
#endif

/** @brief  */
#ifndef HAVE_ENUM_MAV_STATE
#define HAVE_ENUM_MAV_STATE
typedef enum MAV_STATE
{
   MAV_STATE_UNINIT=0, /* Uninitialized system, state is unknown. | */
   MAV_STATE_BOOT=1, /* System is booting up. | */
   MAV_STATE_CALIBRATING=2, /* System is calibrating and not flight-ready. | */
   MAV_STATE_STANDBY=3, /* System is grounded and on standby. It can be launched any time. | */
   MAV_STATE_ACTIVE=4, /* System is active and might be already airborne. Motors are engaged. | */
   MAV_STATE_CRITICAL=5, /* System is in a non-normal flight mode. It can however still navigate. | */
   MAV_STATE_EMERGENCY=6, /* System is in a non-normal flight mode. It lost control over parts or over the whole airframe. It is in mayday and going down. | */
   MAV_STATE_POWEROFF=7, /* System just initialized its power-down sequence, will shut down now. | */
   MAV_STATE_FLIGHT_TERMINATION=8, /* System is terminating itself. | */
   MAV_STATE_ENUM_END=9, /*  | */
} MAV_STATE;
#endif

/** @brief TX2 working mode flag */
#ifndef HAVE_ENUM_MAV_GIMBAL_CONTROL
#define HAVE_ENUM_MAV_GIMBAL_CONTROL
typedef enum MAV_GIMBAL_CONTROL
{
   INFANTRY_ARMOR_MDOE=0, /* TX2 detects the enemy's armor | */
   INFANTRY_RUNE_CLOCK=1, /* Rune mode with clockwise | */
   INFANTRY_RUNE_ANTICLOCK=2, /* Rune mode with anticlockwise | */
   INFANTRY_CURRENT_ANGLE=3, /* Current angle of gimbal | */
   NO_TARGET=4, /* Didn't find any target | */
   SENTINEL_FIRE=5, /* Auto fire mode on sentinel | */
   SENTINEL_ESCAPE=6, /* Escaping mode on sentinel | */
   HERO_BIG_BULLET=7, /* Hero fire with big bullet | */
   HERO_SMALL_BULLET=8, /* Hero fire with small bullet | */
   HERO_LONGSHOOT_MODE=9, /* Hero fire at a long distance | */
   INFANTRY_VELOCITY_15=15, /* Shooting at 15m/s | */
   INFANTRY_VELOCITY_20=20, /* Shooting at 20m/s | */
   INFANTRY_VELOCITY_24=24, /* Shooting at 24m/s | */
   INFANTRY_VELOCITY_28=28, /* Shooting at 28m/s | */
   INFANTRY_RUNE_ANGLE=30, /* Angle in rune mode | */
   MAV_GIMBAL_CONTROL_ENUM_END=31, /*  | */
} MAV_GIMBAL_CONTROL;
#endif

// MAVLINK VERSION

#ifndef MAVLINK_VERSION
#define MAVLINK_VERSION 3
#endif

#if (MAVLINK_VERSION == 0)
#undef MAVLINK_VERSION
#define MAVLINK_VERSION 3
#endif

// MESSAGE DEFINITIONS
#include "./mavlink_msg_heartbeat.h"
#include "./mavlink_msg_gimbal_control.h"
#include "./mavlink_msg_chassis_control.h"

// base include


#undef MAVLINK_THIS_XML_IDX
#define MAVLINK_THIS_XML_IDX 0

#if MAVLINK_THIS_XML_IDX == MAVLINK_PRIMARY_XML_IDX
# define MAVLINK_MESSAGE_INFO {MAVLINK_MESSAGE_INFO_HEARTBEAT, MAVLINK_MESSAGE_INFO_GIMBAL_CONTROL, MAVLINK_MESSAGE_INFO_CHASSIS_CONTROL}
# define MAVLINK_MESSAGE_NAMES {{ "CHASSIS_CONTROL", 2 }, { "GIMBAL_CONTROL", 1 }, { "HEARTBEAT", 0 }}
# if MAVLINK_COMMAND_24BIT
#  include "../mavlink_get_info.h"
# endif
#endif

#ifdef __cplusplus
}
#endif // __cplusplus
#endif // MAVLINK_MAVRM_H
